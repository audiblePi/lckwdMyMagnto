<?php
class Magentothem_Ajaxcartsuper_Block_Ajaxcartconfig extends Mage_Catalog_Block_Product_Abstract
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
}