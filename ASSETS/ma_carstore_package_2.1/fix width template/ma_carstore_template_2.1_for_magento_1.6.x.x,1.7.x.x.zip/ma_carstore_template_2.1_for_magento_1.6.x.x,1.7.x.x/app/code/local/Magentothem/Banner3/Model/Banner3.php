<?php

class Magentothem_Banner3_Model_Banner3 extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('banner3/banner3');
    }
}