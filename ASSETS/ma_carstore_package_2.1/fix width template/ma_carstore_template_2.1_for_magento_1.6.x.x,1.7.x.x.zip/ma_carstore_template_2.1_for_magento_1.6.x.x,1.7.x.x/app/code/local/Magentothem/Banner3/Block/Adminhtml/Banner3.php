<?php
/*------------------------------------------------------------------------
# Websites: http://www.plazathemes.com/
-------------------------------------------------------------------------*/ 
class Magentothem_Banner3_Block_Adminhtml_Banner3 extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_banner3';
    $this->_blockGroup = 'banner3';
    $this->_headerText = Mage::helper('banner3')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('banner3')->__('Add Item');
    parent::__construct();
  }
}