<?php
/*------------------------------------------------------------------------
# Websites: http://www.plazathemes.com/
-------------------------------------------------------------------------*/ 
class Magentothem_Banner3_Block_Banner3 extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getBanner3()     
     { 
        if (!$this->hasData('banner3')) {
            $this->setData('banner3', Mage::registry('banner3'));
        }
        return $this->getData('banner3');
        
    }
	public function getDataBanner3()
    {
    	$resource = Mage::getSingleton('core/resource');
		$read= $resource->getConnection('core_read');
		$slideTable = $resource->getTableName('banner3');	
		$select = $read->select()
		   ->from($slideTable,array('banner3_id','title','link','description','image','status'))
		   ->where('status=?',1);
		$slide = $read->fetchAll($select);	
		return 	$slide;			
    }
	public function getConfig($att) 
	{
		$config = Mage::getStoreConfig('banner3');
		if (isset($config['banner3_config']) ) {
			$value = $config['banner3_config'][$att];
			return $value;
		} else {
			throw new Exception($att.' value not set');
		}
	}
}