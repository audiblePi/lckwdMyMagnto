<?php
/*------------------------------------------------------------------------
# Websites: http://www.plazathemes.com/
-------------------------------------------------------------------------*/ 
class Magentothem_Banner3_IndexController extends Mage_Core_Controller_Front_Action
{
    public function indexAction()
    {
    	
    	/*
    	 * Load an object by id 
    	 * Request looking like:
    	 * http://site.com/banner3?id=15 
    	 *  or
    	 * http://site.com/banner3/id/15 	
    	 */
    	/* 
		$banner3_id = $this->getRequest()->getParam('id');

  		if($banner3_id != null && $banner3_id != '')	{
			$banner3 = Mage::getModel('banner3/banner3')->load($banner3_id)->getData();
		} else {
			$banner3 = null;
		}	
		*/
		
		 /*
    	 * If no param we load a the last created item
    	 */ 
    	/*
    	if($banner3 == null) {
			$resource = Mage::getSingleton('core/resource');
			$read= $resource->getConnection('core_read');
			$banner3Table = $resource->getTableName('banner3');
			
			$select = $read->select()
			   ->from($banner3Table,array('banner3_id','title','content','status'))
			   ->where('status',1)
			   ->order('created_time DESC') ;
			   
			$banner3 = $read->fetchRow($select);
		}
		Mage::register('banner3', $banner3);
		*/

			
		$this->loadLayout();     
		$this->renderLayout();
    }
}