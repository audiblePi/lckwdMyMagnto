<?php
/*------------------------------------------------------------------------
# Websites: http://www.plazathemes.com
-------------------------------------------------------------------------*/ 
class Magentothem_Banner3_Block_Adminhtml_Banner3_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{

  public function __construct()
  {
      parent::__construct();
      $this->setId('banner3_tabs');
      $this->setDestElementId('edit_form');
      $this->setTitle(Mage::helper('banner3')->__('Item Information'));
  }

  protected function _beforeToHtml()
  {
      $this->addTab('form_section', array(
          'label'     => Mage::helper('banner3')->__('Item Information'),
          'title'     => Mage::helper('banner3')->__('Item Information'),
          'content'   => $this->getLayout()->createBlock('banner3/adminhtml_banner3_edit_tab_form')->toHtml(),
      ));
     
      return parent::_beforeToHtml();
  }
}