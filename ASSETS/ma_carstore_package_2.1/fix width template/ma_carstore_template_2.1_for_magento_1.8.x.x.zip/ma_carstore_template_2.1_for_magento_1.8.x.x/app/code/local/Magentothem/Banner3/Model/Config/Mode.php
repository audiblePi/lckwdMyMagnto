<?php
/*------------------------------------------------------------------------
# Websites: http://www.plazathemes.com/
-------------------------------------------------------------------------*/ 
class Magentothem_Banner3_Model_Config_Mode
{

    public function toOptionArray()
    {
        return array(
            array('value'=>'growX', 'label'=>Mage::helper('adminhtml')->__('GrowX')),
            array('value'=>'growY', 'label'=>Mage::helper('adminhtml')->__('GrowY')),
            array('value'=>'scrollUp', 'label'=>Mage::helper('adminhtml')->__('ScrollUp')),
            array('value'=>'scrollDown', 'label'=>Mage::helper('adminhtml')->__('ScrollDown')),
            array('value'=>'scrollLeft', 'label'=>Mage::helper('adminhtml')->__('ScrollLeft')),
            array('value'=>'scrollRight', 'label'=>Mage::helper('adminhtml')->__('ScrollRight'))           
        );
    }

}
